import { useEffect, useState } from 'react'
import styles from "./Cart.module.css";

import axios from 'axios';

const Cart = () => {

  let [userDetails, setUserDetails] = useState({})
  let [loading, setLoading] = useState(true);

  let userid = localStorage.getItem("userid")

  useEffect(() => {
    let getCartItems = async () => {
      let { data } = await axios.get(`http://localhost:6060/users/${userid}`)
      console.log(data);
      setUserDetails(data)
      // console.log(userDetails);
      setLoading(false)
    }
    getCartItems()
  }, [])

  let handleRemovefromCart = async (productid) => {
    try {
      let { data } = await axios.get(`http://localhost:6060/users/${userid}`)
      // console.log(data);
      // console.log(productid);
      let updatedCart = data.cart.map((item)=>{
        if (item.id == productid){
          if (item.quantity > 1){
            return{
              ...item,
              quantity: item.quantity - 1,
              price: Math.floor((item.price/item.quantity) * (item.quantity - 1))
            }
          }else{
            return null
          }
        }
        return item
      })
      .filter((item) => item!==null)
      console.log(updatedCart);

      await axios.patch(`http://localhost:6060/users/${userid}`, {cart: updatedCart})

      setUserDetails({...data, cart: updatedCart})
      
    } catch (error) {
      console.log("Error while removing item", error);
      
    }
  }

  if (loading) {
    return (
      <>
    loading
      </>
    );
  }

  return (
    <div className={styles.cardContainer}>
      <h1>Cart</h1>
      <main>
        {userDetails.cart.map((item) => {
          return (
            <section key={item.id} className={styles.card}>
              <img src={item.image} className={styles.img} />
              <h2 className={styles.title}>{item.title.slice(0, 30)}...</h2>
              <h2 className={styles.quantity}>Quantity : {item.quantity}</h2>
              <h2 className={styles.price}>Price : $ {item.quantity * item.price}</h2>
              <button className={styles.btn} onClick={() => { handleRemovefromCart(item.id) }}>Remove</button>
            </section>
          )
        })}
      </main>
    </div>
  )
}
export default Cart
